<?php

OCP\App::registerAdmin('shorten', 'admin');

OCP\Util::addScript( 'shorten', "script" );
OCP\Util::addScript( 'shorten', "admin" );
